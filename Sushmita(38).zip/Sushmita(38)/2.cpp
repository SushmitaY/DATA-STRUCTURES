//Program to test whether values of consecutive pairs of elements in a stack are consecutive or not 

#include<iostream>
#include<stack>
#include<cmath>
using namespace std;

bool testStack(stack<int> s){
	/*
	Objective: To test whether values of consecutive pairs of elements in a stack are consecutive or not.
	Input: s -> A stack
	Output: None
	Return: True, if consecutive.
		False, if not consecutive. 
	*/
	if(s.size()%2 != 0)	
		s.pop();
	while(!s.empty()){
		int x = s.top();
		s.pop();
		int y = s.top();
		s.pop();
		if(abs(x-y)!=1)
			return false;
	}
	return true;
}

int main(){
	/*
	Objective: Driver fuction for testing of values in a stack.
	*/
	stack<int> s;	
	s.push(2);
	s.push(3);
	s.push(7);
	s.push(6);
	s.push(1);
	s.push(2);
	s.push(5);
	s.push(9);
	if(testStack(s))
		cout<<"\nYes,successive pair of numbers in the stack is consecutive\n";
	else
		cout<<"\nNo,successive pair of numbers in the stack is not consecutive\n";
	return 0;
}

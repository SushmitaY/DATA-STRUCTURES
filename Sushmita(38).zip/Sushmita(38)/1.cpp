//Program to test whether the stack on the machine grows upward or downward

/*
	1. Declare a variable in main - "var_main".
	2. Call another function from main and pass address of the variable declared - "addr_main".
	3. Inside the new function, declare a variable - "var_func".
	4. Compare address of the new variable - "addr_func" with "addr_main"
	5. If  "addr_func" > "addr_main" , stack grows upward
		otherwise, stack grows downward
	
	**This works because the new(or called) function is allocated memory either above or below the main function(or calling function) 		                                    depending on the architechture of machine**
*/

#include<iostream>
using namespace std;

void function(int *addr_main){

	/*
	Objective: To test the direction of growth of stack
	Input: addr_main - address of a variable which is local to main() function.
	Output: Direction of stack growth.(Upward/Downward)
	Return value: None
	*/
	int var_func;
	int *addr_func = &var_func;
	if( addr_main < addr_func)
		cout<<"\nStack grows upward\n";
	else
		cout<<"\nStack grows downward\n";
}
int main(){
	/*
	Objective: Driver function to find stack growth direction.
	*/
   	int var_main;
	function(&var_main);
	return 0;
}

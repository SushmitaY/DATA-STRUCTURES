//Program to print all root - leaf paths of a binary tree

#include<iostream>
using namespace std;

class BNode{
	/*   			
	objective: Create a class for a Node for Binary Tree
	input parameters: none
	output value: none
	description: BNode class defines the node structure 
	approach: Class defines data item is names element with datatype int,
                  left link is named left of BNode type,
		  and right link is named right of BNode type.
	*/
	public:
		int elem;
		BNode* left;
		BNode* right;
};

BNode* getnode(int e){
    
       /*
       Objective: To create a new object of class BNode, initialize its members and return its pointer.
       Input: An integer
       Output: None
       Return value: A Pointer to the object of class BNode.
       */

	BNode* temp = new BNode;
	temp->elem = e;
	temp->left = NULL;
	temp->right = NULL;
	return temp;
}
	
void printPath(int path_array[],int path_length){
	/*
	Object: To print path from root to some leaf
	Input: path_array - Array in which the path is stored
	       path_length - length of the path
	Output: path from root to a leaf
	Return value: None 	
	*/
	cout<<"\nPATH: ";
	for(int i=0;i<path_length;i++)
		cout<<path_array[i]<<"-->";
	cout<<"\n";
}

void printPathRec(BNode* root,int path_array[],int length){
	
	/*
	Objective: To recursively obtain all the root-leaf paths in a binary tree 
	Input: root->current node being traversed
	       path_array -> path from root of the original tree till the current node being traversed is stored in this array. 
			     when a leaf is reached, printPath() function is called which print path from root to this particular leaf.
	       length -> length of the path from root of original tree to current node. 	 	
	Output:None
	Return value:None
	*/
		
	if(root == NULL)
		return;
	path_array[length++] = root->elem;
	if(root->left == NULL && root->right == NULL)
		printPath(path_array,length);
	else{
		printPathRec(root->left, path_array,length);
		printPathRec(root->right, path_array,length);
	}
}

void printAllPath(BNode* root){
	/*
	Objective: To trigger the printPathRec(...) function which finds all root-leaf paths of a binary tree recursively.
	Input: root -> root node of the binary tree.
	Output: None
	Return value: None
	*/
	int path_array[100];
	printPathRec(root,path_array,0);
}
int main(){

	/*
	Objective: Driver function to print all root-leaf baths of a binary tree
	
	Tree in this example is:

				10
                              /    \
			     /      \
			    /        \
			   9          8
			 /  \       /   \
			/    \     /     \
		       6      7   5       4
		      / \      \
		     /   \      \
		    3	  1      2

	*/

	BNode* root = NULL;
	root = getnode(10);
	root->left = getnode(9);
	root->right = getnode(8);
	root->left->right = getnode(7);
	root->left->left = getnode(6);
	root->right->left = getnode(5);
	root->right->right = getnode(4);
	root->left->left->left = getnode(3);
	root->left->right->right = getnode(2);
	root->left->left->right = getnode(1);
	printAllPath(root);
	return 0;
}

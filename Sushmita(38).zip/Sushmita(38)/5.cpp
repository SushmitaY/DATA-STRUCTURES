//Program to find leader of a group
 
#include<iostream>

using namespace std;

class SNode { 
	/*   			
	objective: Create a class for a Node for Single Linked list
	input parameters: none
	output value: none
	description: SNode class defines the node structure 
	approach: Class defines data item is names element with datatype int
			and link is named next of snode type
	*/
	public:
	  int elem; 
	  SNode* next; 
};

SNode* getNode(const int e){

    /*
    Objective: To create a new object of class SNode, initialize its members and return its pointer.
    Input: An integer
    Output: None
    Return value: A Pointer to the object of class SNode.
    */
	SNode* temp = new SNode();
	temp->elem = e;
	temp->next = NULL;
	return temp;
}

void addBack(SNode** head, const int e){
    /*
    Objective: To insert a node at the end of list.
    Input: e -> The element to be inserted.
	   head -> starting node of the list
    Output: None
    Return value: None
    */
	SNode* temp = getNode(e);
	if(*head == NULL)
		*head = temp;
	else{
		SNode* t = *head;
		while(t->next != NULL)
			t = t->next;
		t->next = temp;
	}
}

void make_circular(SNode** head){

	/* 
	Objective: To make a singly Linked list circular by connecting last and first node.
	Input: head -> first node of the list
	Ouput: None
	Return value: None   
	*/
	if(*head == NULL)
		return;
	SNode* temp = *head;
	while(temp->next!=NULL)
		temp = temp->next;
	temp->next = *head;
}

int find_leader(SNode** head, int m){

	/* 
	Objective: To find the position of the leader in a group of people.
	Input: head -> first node of the list of people.
	       m -> every mth position is to eliminated until only one person of the group is left. 
	Ouput: None
	Return value: position of the leader   
	*/
	if(head == NULL)
		return -1;
	SNode* curr = *head;
	SNode* prev = *head;
	while((*head)->next != *head){
		int count = m-1;
		while(count-- > 0 ){
			prev = curr;
			curr = curr->next;
		}
		if(curr == *head)	
			*head = curr->next;
		SNode* temp = curr;
		prev->next = curr->next;
		curr = prev->next;
		delete temp;
	}
	return (*head)->elem;
}

void create_group(SNode** head, int n){
	/* 
	Objective: To create a linked list with n nodes where the nodes have values from 1 to n (position of a person).
	Input: head -> first node of the list
	       n -> number of nodes in the list	
	Ouput: None
	Return value: None   
	*/
	for(int i=1;i<=n;i++)
		addBack(head,i);
}
int main(){
	/*
	Objective: Driver function to find leader in a group of people.
	*/
	SNode* head = NULL;
	int n,m;
	cout<<"\nEnter no. of people in group: ";
	cin>>n;
	create_group(&head, n);
	make_circular(&head);
	cout<<"\nEnter the mth position of elimination: ";
	cin>>m;
	cout<<"\nLEADER IS PERSON AT POSITION: "<<find_leader(&head,m)<<"\n";
	return 0;
}


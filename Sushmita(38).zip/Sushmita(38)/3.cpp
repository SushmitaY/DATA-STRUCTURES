//Program to reverse nodes of a linked list pairwise
 
#include<iostream>

using namespace std;

class SNode { 
	/*   			
	objective: Create a class for a Node for Single Linked list
	input parameters: none
	output value: none
	description: SNode class defines the node structure 
	approach: Class defines data item is names element with datatype int 
			and link is named next of snode type
	*/
	private:
	  int elem; 
	  SNode* next; 
	friend class SLinkedList; // provides SLinkedList access to SNode
};


class SLinkedList { 
	/*   			
	objective: Create a Single LInked List class 
	input parameters: none
	output value: none
	side effects: Class SlinkedList defines Single Linked List class
	approach: Class definition
	*/						
	public:
	SLinkedList();							// empty list constructor
	~SLinkedList();							// destructor
	SNode* getNode(const int e);					// creates a new SNode and returns its pointer
	void addBack(const int e); 					// add to back of list
	void print(); 							// prints the SLL
	void reverse_pairs();						// reverses the nodes of list pairwise. 
	private:
	SNode* head; 							// pointer to the head of list
};

SLinkedList::SLinkedList(){

    /*
    Objective: To construct an object of class SLinkedList and initialize head with NULL.
    Input: None
    Output: None
    Return value: None
    */
    
	head = NULL;
}

SLinkedList::~SLinkedList(){
    
    /*
    Objective: To destruct the object of class SLinkedList.
    Input: None
    Output: None
    Return value: None
    */
    
	SNode* curr = head;
	while(curr != NULL){
		SNode* next = curr->next;
		delete curr;
		curr = next;
	}
	head = NULL;
}

SNode* SLinkedList::getNode(const int e){

    /*
    Objective: To create a new object of class SNode, initialize its members and return its pointer.
    Input: A string
    Output: None
    Return value: A Pointer to the object of class SNode.
    */
	SNode* temp = new SNode();
	temp->elem = e;
	temp->next = NULL;
	return temp;
}

void SLinkedList::addBack(const int e){
    /*
    Objective: To insert a node at the end of list.
    Input: e -> The element to be inserted.
    Output: None
    Return value: None
    */
	SNode* temp = getNode(e);
	if(head == NULL)
		head = temp;
	else{
		SNode* t = head;
		while(t->next != NULL)
			t = t->next;
		t->next = temp;
	}
}

void SLinkedList::reverse_pairs(){

    /*
    Objective: To reverse nodes of list pairwise.
    Input: None
    Output: None
    Return value: None
    Side effect: Head is updated to the second element of the original list if more than one node is present in the list.
    */
	if(head==NULL || head->next==NULL)
		return;
	SNode* t1 = head;
	SNode* t2 = head->next;
	SNode* prev = NULL;
	head = t2;

	while(t1!=NULL && t2!=NULL){
		if(prev!=NULL)
			prev->next = t2;
		t1->next = t2->next;
		t2->next = t1;		
		prev = t1;
		t1 = prev->next;
		if(prev->next != NULL)
			t2 = prev->next->next;
		else
			t2 = NULL;
	}	
}

void SLinkedList::print(){
    
    /*
    Objective: To display the list
    Input: None
    Output: List data
    Return value: None
    */
	cout<<"\n\n---------------------------------LIST-------------------------------------------\n";
	SNode* curr = head;
	while(curr != NULL){
		cout<<curr->elem<<"\t";
		curr = curr->next; 	
	}
	cout<<"\n----------------------------------------------------------------------------------\n";
}


int main(){
	/*
	Objective: Driver function to visualize pairwise reversal of nodes of a list.
	*/
	SLinkedList l;
	l.addBack(1);
	l.addBack(2);
	l.addBack(3);
	l.addBack(4);
	l.addBack(5);
	l.print();
	l.reverse_pairs();
	cout<<"\n\t\t\tAFTER REVERSAL";
	l.print();
	return 0;
}


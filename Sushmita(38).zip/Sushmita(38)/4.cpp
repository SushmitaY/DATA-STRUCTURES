//Program to split a circular list in two halves.

#include<iostream>

using namespace std;

class SNode { 
	/*   			
	objective: Create a class for a Node for Single Linked list
	input parameters: none
	output value: none
	description: SNode class defines the node structure 
	approach: Class defines data item is names element with datatype int 
			and link is named next of snode type
	*/
	public:
	  int elem; 
	  SNode* next; 
};

SNode* getNode(const int e){

    /*
    Objective: To create a new object of class SNode, initialize its members and return its pointer.
    Input: An integer
    Output: None
    Return value: A Pointer to the object of class SNode.
    */
	SNode* temp = new SNode();
	temp->elem = e;
	temp->next = NULL;
	return temp;
}

void addBack(SNode** head, const int e){
    /*
    Objective: To insert a node at the end of list.
    Input: e -> The element to be inserted.
	   head -> starting node of the list
    Output: None
    Return value: None
    */
	SNode* temp = getNode(e);
	if(*head == NULL)
		*head = temp;
	else{
		SNode* t = *head;
		while(t->next != NULL)
			t = t->next;
		t->next = temp;
	}
}

void make_circular(SNode** head){

	/* 
	Objective: To make a singly Linked list circular by connecting last and first node.
	Input: head -> first node of the list
	Ouput: None
	Return value: None   
	*/
	if(*head==NULL)
		return;
	SNode* temp = *head;
	while(temp->next!=NULL)
		temp = temp->next;
	temp->next = *head;
}


void print(SNode* head){
    
    /*
    Objective: To display the list
    Input: head -> starting node of the list
    Output: List data
    Return value: None
    */
	cout<<"\n\n---------------------------------LIST-------------------------------------------\n";
	SNode* curr = head;
	if(head!=NULL){
		do{
			cout<<curr->elem<<"\t";
			curr = curr->next; 	
		}while(curr != head);
	}
	cout<<"\n----------------------------------------------------------------------------------\n";
}

void split_list(SNode* head,SNode** head1,SNode** head2){

	/*
	Objective: To split one circular linked list into two circuar linked list of equal size if size is even, otherwise first list has size 			   one greater than second.  
	Input: head -> First node of original list.
	       head1 -> It will point to the head of first list after splitting.
	       head2 -> It will point to the head of second list after splitting.
	Output: None
	Approach: Using Floyd's Algorithm to detect cycles, i.e using one fast pointer and one slow pointer.
		  In this case, fast pointer iterates twice as fast as slow pointer.
	Return value: None
	*/

	if(head == NULL)
		return;
	SNode* slow = head;
	SNode* fast = head;
	while(fast->next != head && fast->next->next != head){
		fast = fast->next->next;
		slow = slow->next;
	}
	if(fast->next->next == head)
		fast = fast->next;
	*head1 = head;
	*head2 = slow->next;
	fast->next = *head2;
	slow->next = *head1; 
}

int main(){

	/*
	Objective: Driver function to split one circular linked in two halves.
	*/

	SNode* head = NULL;
	addBack(&head,1);
	addBack(&head,2);
	addBack(&head,3);
	addBack(&head,4);
	addBack(&head,5);
	make_circular(&head);
	print(head);
	SNode* head1 = NULL;
	SNode* head2 = NULL;
	split_list(head, &head1, &head2);
	cout<<"\n\t\t\tAFTER SPLITING";
	print(head1);
	print(head2);
	return 0;
}

